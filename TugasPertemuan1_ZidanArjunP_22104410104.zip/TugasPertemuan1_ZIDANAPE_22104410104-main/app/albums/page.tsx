const albums = () => {
    return (
        <div>aALBUM PAGE</div>
    )
}

export default albums